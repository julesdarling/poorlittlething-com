POOR LITTLE THING
STL COLLECTION

18 assembly STL files. Units: millimeters.

Each file contains the complete assembly displayed on the website.
These are displayed assemblies rather than laid-out production parts.
Import the files as millimeters and prepare the layout and slicing
for your own printer and workflow.

CONTENTS
- alligator-assembly-mm.stl
- block-party-assembly-mm.stl
- bramble-assembly-mm.stl
- bunny-sweep-assembly-mm.stl
- crank-assembly-mm.stl
- crescent-assembly-mm.stl
- flame-collar-assembly-mm.stl
- little-c-assembly-mm.stl
- orbit-assembly-mm.stl
- palm-heart-assembly-mm.stl
- palm-star-assembly-mm.stl
- puppy-fold-assembly-mm.stl
- rope-saw-assembly-mm.stl
- scallop-assembly-mm.stl
- tall-sweep-assembly-mm.stl
- talon-assembly-mm.stl
- tenderizer-assembly-mm.stl
- trio-assembly-mm.stl
